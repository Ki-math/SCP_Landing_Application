/*
 * File: gncCore_lib_terminate.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 2026/08/28 19:09:09
 */

/* Include Files */
#include "gncCore_lib_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void gncCore_lib_terminate(void)
{
}

/*
 * File trailer for gncCore_lib_terminate.c
 *
 * [EOF]
 */
