/*
 * File: gncCore_lib_terminate.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 2026/08/29 11:14:48
 */

#ifndef GNCCORE_LIB_TERMINATE_H
#define GNCCORE_LIB_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void gncCore_lib_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for gncCore_lib_terminate.h
 *
 * [EOF]
 */
